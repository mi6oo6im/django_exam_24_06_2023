from django.urls import path
from . import views

"""
•	[http://localhost:8000/](http://localhost:8000/) - index page <br>
•	[http://localhost:8000/dashboard/](http://localhost:8000/dashboard/) - dashboard page <br>

•	[http://localhost:8000/profile/create/](http://localhost:8000/profile/create/) - profile create page <br>
•	[http://localhost:8000/profile/details/](http://localhost:8000/profile/details/) - profile details page <br>
•	[http://localhost:8000/profile/edit/](http://localhost:8000/profile/edit/) - profile edit page <br>
•	[http://localhost:8000/profile/delete/ ](http://localhost:8000/profile/delete/ )- profile delete page <br>

•	[http://localhost:8000/create/](http://localhost:8000/create/) - fruit create page <br>
•	[http://localhost:8000/1/details/](http://localhost:8000/1/details/) - fruit details page <br>
•	[http://localhost:8000/1/edit/](http://localhost:8000/1/edit/) - fruit edit page <br>
•	[http://localhost:8000/1/delete/ ](http://localhost:8000/1/delete/ )- fruit delete page
"""

urlpatterns = (
    path('', views.index, name='index'),
    path('dashboard/', views.dashboard, name='dashboard'),
    # profile urls:
    path('profile/create/', views.profile_create, name='create profile'),
    path('profile/details/', views.profile_details, name='profile details'),
    path('profile/edit/', views.profile_edit, name='edit profile'),
    path('profile/delete/', views.profile_delete, name='delete profile'),
    # fruit urls:
    path('fruit/create/', views.fruit_create, name='create fruit'),
    path('fruit/details/<int:pk>/', views.fruit_details, name='fruit details'),
    path('fruit/edit/<int:pk>/', views.fruit_edit, name='edit fruit'),
    path('fruit/delete/<int:pk>/', views.fruit_delete, name='delete fruit'),
)